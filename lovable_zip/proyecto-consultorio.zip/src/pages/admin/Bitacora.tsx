import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Shield, Filter, Download } from "lucide-react";

const logs = [
  { fecha: "25/03/2026 14:30:12", usuario: "admin", accion: "Inicio de sesión", modulo: "Sistema", ip: "192.168.1.10", detalle: "Login exitoso" },
  { fecha: "25/03/2026 14:28:45", usuario: "dgarcia", accion: "Actualización", modulo: "Expediente", ip: "192.168.1.15", detalle: "Expediente #1234 actualizado" },
  { fecha: "25/03/2026 14:15:30", usuario: "dgarcia", accion: "Creación", modulo: "Citas", ip: "192.168.1.15", detalle: "Cita creada para María López" },
  { fecha: "25/03/2026 13:45:00", usuario: "recepcion1", accion: "Consulta", modulo: "Reportes", ip: "192.168.1.20", detalle: "Reporte de citas generado" },
  { fecha: "25/03/2026 13:00:22", usuario: "admin", accion: "Creación", modulo: "Usuarios", ip: "192.168.1.10", detalle: "Usuario 'enfermera1' creado" },
  { fecha: "25/03/2026 12:30:11", usuario: "dgarcia", accion: "Actualización", modulo: "Expediente", ip: "192.168.1.15", detalle: "Padecimiento actual registrado" },
  { fecha: "25/03/2026 11:45:33", usuario: "recepcion1", accion: "Eliminación", modulo: "Citas", ip: "192.168.1.20", detalle: "Cita #567 cancelada" },
  { fecha: "25/03/2026 08:00:05", usuario: "recepcion1", accion: "Inicio de sesión", modulo: "Sistema", ip: "192.168.1.20", detalle: "Login exitoso" },
];

const actionColor: Record<string, string> = {
  "Inicio de sesión": "bg-primary/10 text-primary",
  "Creación": "bg-success/10 text-success",
  "Actualización": "bg-warning/10 text-warning",
  "Eliminación": "bg-destructive/10 text-destructive",
  "Consulta": "bg-muted text-muted-foreground",
};

export default function Bitacora() {
  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold text-foreground">Bitácora de Actividad</h1>
        </div>
        <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1" /> Exportar</Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-wrap items-end gap-3 mb-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Desde</label>
              <Input type="date" className="w-40" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Hasta</label>
              <Input type="date" className="w-40" />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Usuario</label>
              <Select defaultValue="todos">
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="admin">admin</SelectItem>
                  <SelectItem value="dgarcia">dgarcia</SelectItem>
                  <SelectItem value="recepcion1">recepcion1</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Módulo</label>
              <Select defaultValue="todos">
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="sistema">Sistema</SelectItem>
                  <SelectItem value="expediente">Expediente</SelectItem>
                  <SelectItem value="citas">Citas</SelectItem>
                  <SelectItem value="reportes">Reportes</SelectItem>
                  <SelectItem value="usuarios">Usuarios</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button size="sm"><Filter className="h-4 w-4 mr-1" /> Filtrar</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha / Hora</TableHead>
                <TableHead>Usuario</TableHead>
                <TableHead>Acción</TableHead>
                <TableHead>Módulo</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Detalle</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map((log, i) => (
                <TableRow key={i}>
                  <TableCell className="font-mono text-xs">{log.fecha}</TableCell>
                  <TableCell className="font-medium">{log.usuario}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={actionColor[log.accion] || ""}>
                      {log.accion}
                    </Badge>
                  </TableCell>
                  <TableCell>{log.modulo}</TableCell>
                  <TableCell className="font-mono text-xs">{log.ip}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{log.detalle}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="p-3 border-t text-xs text-muted-foreground">
            Mostrando {logs.length} registros
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
