import { useState } from "react";
import { useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Save } from "lucide-react";

export default function ExpedienteDetalle() {
  const { id } = useParams();
  const isNew = !id || id === "nuevo";

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-foreground">Expediente</h1>
        <Button variant="default" className="bg-primary">
          <span className="text-sm">Precio Consulta</span>
        </Button>
      </div>

      <Tabs defaultValue="datos" className="space-y-4">
        <TabsList className="bg-muted">
          <TabsTrigger value="datos">Datos Personales del Paciente</TabsTrigger>
          <TabsTrigger value="antecedentes">Antecedentes Personales</TabsTrigger>
          <TabsTrigger value="padecimiento">Padecimiento Actual</TabsTrigger>
          <TabsTrigger value="notas">Notas</TabsTrigger>
        </TabsList>

        {/* Tab 1: Datos Personales */}
        <TabsContent value="datos">
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 lg:grid-cols-[1fr_180px] gap-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Field label="Clínica" required>
                    <Select defaultValue="central">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="central">Clínica Central</SelectItem>
                        <SelectItem value="norte">Clínica Norte</SelectItem>
                        <SelectItem value="sur">Clínica Sur</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Tipo Identificación">
                    <Select defaultValue="cedula">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cedula">Cédula Nacional</SelectItem>
                        <SelectItem value="pasaporte">Pasaporte</SelectItem>
                        <SelectItem value="residencia">Residencia</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Número de Identificación"><Input defaultValue={isNew ? "" : "1-0234-0567"} /></Field>
                  <Field label="Teléfono Casa"><Input defaultValue={isNew ? "" : "2234-5678"} /></Field>
                  <Field label="Nombre" required><Input defaultValue={isNew ? "" : "María"} /></Field>
                  <Field label="Teléfono Celular"><Input defaultValue={isNew ? "" : "8812-3456"} /></Field>
                  <Field label="Apellido 1" required><Input defaultValue={isNew ? "" : "López"} /></Field>
                  <Field label="Teléfono Trabajo"><Input /></Field>
                  <Field label="Apellido 2"><Input defaultValue={isNew ? "" : "Jiménez"} /></Field>
                  <Field label="Otro Teléfono"><Input /></Field>
                  <Field label="Sexo">
                    <Select defaultValue="femenino">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="masculino">Masculino</SelectItem>
                        <SelectItem value="femenino">Femenino</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Estado Civil">
                    <Select defaultValue="soltero">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="soltero">Soltero</SelectItem>
                        <SelectItem value="casado">Casado</SelectItem>
                        <SelectItem value="divorciado">Divorciado</SelectItem>
                        <SelectItem value="viudo">Viudo</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Dirección" full><Input defaultValue={isNew ? "" : "San José, Costa Rica"} /></Field>
                  <Field label="Email" full><Input type="email" defaultValue={isNew ? "" : "maria@email.com"} /></Field>
                  <Field label="Médico" required>
                    <Select defaultValue="garcia">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="garcia">Dr. García</SelectItem>
                        <SelectItem value="sanchez">Dr. Sánchez</SelectItem>
                        <SelectItem value="vargas">Dra. Vargas</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Ocupación"><Input /></Field>
                  <Field label="Fecha Nacimiento"><Input type="date" defaultValue="1990-03-01" /></Field>
                  <Field label="Tipo de Sangre">
                    <Select>
                      <SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
                      <SelectContent>
                        {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map(t => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                </div>

                {/* Photo */}
                <div className="flex flex-col items-center gap-3">
                  <div className="w-36 h-40 bg-muted rounded-lg flex items-center justify-center border">
                    <User className="h-16 w-16 text-muted-foreground/40" />
                  </div>
                  <Button variant="outline" size="sm">Cambiar Fotografía</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Antecedentes */}
        <TabsContent value="antecedentes">
          <Card>
            <CardContent className="pt-6 space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Antecedentes Personales Patológicos</Label>
                  <Textarea className="min-h-[120px]" placeholder="Ingrese antecedentes patológicos..." />
                </div>
                <div className="space-y-3">
                  <Label className="text-sm font-semibold">Antecedentes Personales No Patológicos</Label>
                  <div className="space-y-2">
                    {["Tabaco", "Etilismo", "Ejercicio", "Transfusión", "Alergias", "Drogas"].map(item => (
                      <div key={item} className="flex items-center gap-2">
                        <Checkbox id={item} />
                        <label htmlFor={item} className="text-sm">{item}</label>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Antecedentes Quirúrgicos y Traumáticos</Label>
                  <Textarea className="min-h-[120px]" placeholder="Ingrese antecedentes quirúrgicos..." />
                </div>
                <div className="space-y-3">
                  <Label className="text-sm font-semibold">Antecedentes Gineco-Obstétricos</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {["FUR", "Menopausia", "TRH", "Planificación", "Patol. Mamas", "FUPAP", "IRS", "# CS", "Menarca"].map(f => (
                      <Field key={f} label={f}><Input className="h-8" /></Field>
                    ))}
                  </div>
                  <Label className="text-sm font-semibold mt-3">GPAC</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {["G", "P", "A", "C"].map(f => (
                      <Field key={f} label={f}><Input className="h-8" /></Field>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Antecedentes Heredo-Familiares</Label>
                  <Textarea className="min-h-[120px]" placeholder="Ingrese antecedentes familiares..." />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Otros</Label>
                  <Textarea className="min-h-[120px]" placeholder="Otros antecedentes..." />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Padecimiento Actual */}
        <TabsContent value="padecimiento">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <Checkbox id="ocultos" /><label htmlFor="ocultos" className="mr-4">Mostrar items ocultos</label>
                <Button variant="outline" size="sm">Comparar</Button>
              </div>

              <div className="border rounded-lg p-4 space-y-4 bg-accent/20">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Field label="Fecha"><Input type="date" defaultValue="2026-03-25" /></Field>
                  <Field label="Médico">
                    <Select defaultValue="garcia">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="garcia">Dr. García</SelectItem>
                        <SelectItem value="sanchez">Dr. Sánchez</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Hora"><Input defaultValue="02:09 PM" readOnly /></Field>
                  <div className="flex items-end">
                    <Checkbox id="ocultar" /><label htmlFor="ocultar" className="text-xs ml-1">Ocultar</label>
                  </div>
                </div>

                <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
                  {[
                    { l: "Peso", u: "kg" }, { l: "Talla", u: "mts" }, { l: "IMC", u: "" },
                    { l: "Temp.", u: "" }, { l: "P. Arterial", u: "" }, { l: "FC", u: "" },
                    { l: "FR", u: "" }, { l: "SatO2", u: "%" }
                  ].map(v => (
                    <div key={v.l} className="space-y-1">
                      <label className="text-[10px] text-muted-foreground">{v.l}</label>
                      <Input className="h-7 text-xs" />
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-2 bg-warning/10 p-2 rounded">
                  <Badge variant="outline" className="text-xs">Total Img: 0</Badge>
                  <span className="text-xs">Gabinete/Lab</span>
                  <Select defaultValue="lab">
                    <SelectTrigger className="h-7 text-xs w-48"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lab">Examen de Laboratorio (0)</SelectItem>
                      <SelectItem value="rx">Rayos X (0)</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="secondary" className="h-7 text-xs">Agregar Imágenes</Button>
                  <Button size="sm" variant="secondary" className="h-7 text-xs">Ver Imágenes</Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">Motivo de Consulta</Label>
                    <Textarea className="min-h-[100px]" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">Indicaciones y Tratamientos</Label>
                    <Textarea className="min-h-[100px]" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">Examen Físico</Label>
                    <Textarea className="min-h-[100px]" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold">Impresión Diagnóstica</Label>
                    <Textarea className="min-h-[100px]" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 4: Notas */}
        <TabsContent value="notas">
          <Card>
            <CardContent className="pt-6">
              <Textarea className="min-h-[400px]" placeholder="Notas del paciente..." />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center pt-2">
        <Button size="lg"><Save className="h-4 w-4 mr-2" /> Guardar Expediente</Button>
      </div>
    </div>
  );
}

function Field({ label, children, required, full }: { label: string; children: React.ReactNode; required?: boolean; full?: boolean }) {
  return (
    <div className={`space-y-1 ${full ? "md:col-span-2" : ""}`}>
      <label className="text-xs font-medium text-muted-foreground">
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );
}
