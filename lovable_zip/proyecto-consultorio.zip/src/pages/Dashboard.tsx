import { CalendarDays, Users, FolderOpen, Building2, Activity, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";

const stats = [
  { label: "Citas Hoy", value: "12", icon: CalendarDays, color: "text-primary", href: "/citas" },
  { label: "Pacientes", value: "1,847", icon: Users, color: "text-success", href: "/expediente/buscar" },
  { label: "Expedientes", value: "3,205", icon: FolderOpen, color: "text-warning", href: "/expediente/buscar" },
  { label: "Clínicas", value: "3", icon: Building2, color: "text-primary", href: "/mantenimientos/clinicas" },
];

const recentActivity = [
  { time: "14:30", action: "Cita creada", detail: "María López - Dr. García", type: "cita" },
  { time: "14:15", action: "Expediente actualizado", detail: "Juan Pérez - Antecedentes", type: "expediente" },
  { time: "13:45", action: "Cita atendida", detail: "Ana Rodríguez - Consulta general", type: "cita" },
  { time: "13:00", action: "Nuevo paciente", detail: "Carlos Jiménez - Clínica Central", type: "paciente" },
  { time: "12:30", action: "Reporte generado", detail: "Citas del mes - Marzo 2026", type: "reporte" },
];

const upcomingAppointments = [
  { time: "15:00", patient: "Laura Mora", doctor: "Dr. García", type: "Consulta general" },
  { time: "15:30", patient: "Roberto Arias", doctor: "Dr. Sánchez", type: "Control" },
  { time: "16:00", patient: "Carmen Solano", doctor: "Dr. García", type: "Primera vez" },
  { time: "16:30", patient: "Diego Herrera", doctor: "Dra. Vargas", type: "Seguimiento" },
];

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Panel Principal</h1>
        <p className="text-sm text-muted-foreground">Bienvenido al Sistema Clínico Médico</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(s => (
          <Link key={s.label} to={s.href}>
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="flex items-center gap-4 p-5">
                <div className={`p-3 rounded-lg bg-accent ${s.color}`}>
                  <s.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              Próximas Citas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {upcomingAppointments.map((a, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent/50 transition-colors">
                <span className="text-xs font-mono font-medium text-primary w-12">{a.time}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{a.patient}</p>
                  <p className="text-xs text-muted-foreground">{a.doctor} · {a.type}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Activity */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              Actividad Reciente
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentActivity.map((a, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-md hover:bg-accent/50 transition-colors">
                <span className="text-xs font-mono text-muted-foreground w-12">{a.time}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{a.action}</p>
                  <p className="text-xs text-muted-foreground">{a.detail}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
