import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Stethoscope, AlertCircle } from "lucide-react";
import { usuarios } from "@/data/mockDoctorData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

export default function Login() {
  const navigate = useNavigate();
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const found = usuarios.find(u => u.usuario === user);
    if (!found) {
      setError("Usuario no encontrado.");
      return;
    }
    if (found.rol === "Médico") {
      setError("Este usuario es médico. Use el Portal Médico para ingresar.");
      return;
    }
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/30 p-4">
      <Card className="w-full max-w-md shadow-xl border-0">
        <CardContent className="pt-8 pb-6 px-5 sm:pt-10 sm:pb-8 sm:px-8">
          <div className="flex flex-col items-center mb-6 sm:mb-8">
            <div className="h-14 w-14 sm:h-16 sm:w-16 rounded-2xl bg-primary flex items-center justify-center mb-4">
              <Stethoscope className="h-7 w-7 sm:h-8 sm:w-8 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">
              S<span className="text-primary">C</span>M
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Sistema Clínico Médico</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="user">Usuario</Label>
              <Input
                id="user"
                value={user}
                onChange={e => setUser(e.target.value)}
                placeholder="Ingrese su usuario"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pass">Contraseña</Label>
              <Input
                id="pass"
                type="password"
                value={pass}
                onChange={e => setPass(e.target.value)}
                placeholder="Ingrese su contraseña"
              />
            </div>
            {error && (
              <div className="flex items-center gap-2 text-destructive text-sm">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {error.includes("Portal Médico") && (
              <a href="/doctor" className="text-sm text-primary hover:underline block text-center">
                Ir al Portal Médico →
              </a>
            )}
            <div className="flex gap-3 pt-2">
              <Button type="submit" className="flex-1">Aceptar</Button>
              <Button type="button" variant="outline" className="flex-1" onClick={() => { setUser(""); setPass(""); setError(""); }}>
                Cancelar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
