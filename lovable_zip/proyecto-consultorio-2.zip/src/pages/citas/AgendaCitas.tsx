import { useState } from "react";
import { profesionales } from "@/data/mockDoctorData";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, ChevronDown, ChevronUp } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const hours = Array.from({ length: 15 }, (_, i) => {
  const h = i + 8;
  return `${h > 12 ? h - 12 : h}:00 ${h >= 12 ? "PM" : "AM"}`;
});

const days = [
  { date: "25", day: "mié", dayFull: "miércoles", today: true },
  { date: "26", day: "jue", dayFull: "jueves", today: false },
  { date: "27", day: "vie", dayFull: "viernes", today: false },
];

const mockAppointments = [
  { day: 0, hour: 2, patient: "María López", type: "Consulta", doctor: "Dr. García" },
  { day: 0, hour: 4, patient: "Juan Pérez", type: "Control", doctor: "Dr. García" },
  { day: 1, hour: 1, patient: "Ana Rodríguez", type: "Primera vez", doctor: "Dr. Sánchez" },
  { day: 2, hour: 6, patient: "Carlos Jiménez", type: "Seguimiento", doctor: "Dra. Vargas" },
];

export default function AgendaCitas() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showSidePanel, setShowSidePanel] = useState(false);
  const isMobile = useIsMobile();

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h1 className="text-xl md:text-2xl font-bold text-foreground">Agenda de Citas</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size={isMobile ? "sm" : "default"}>
              <Plus className="h-4 w-4 mr-1" /> {isMobile ? "Nueva" : "Nueva Cita"}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] md:max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Crear Cita</DialogTitle>
            </DialogHeader>
            <CrearCitaForm onClose={() => setDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col lg:flex-row gap-4">
        {/* Left panel - collapsible on mobile */}
        {isMobile && (
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => setShowSidePanel(!showSidePanel)}
          >
            {showSidePanel ? <ChevronUp className="h-4 w-4 mr-1" /> : <ChevronDown className="h-4 w-4 mr-1" />}
            Calendario y opciones
          </Button>
        )}

        {(!isMobile || showSidePanel) && (
          <div className="w-full lg:w-64 space-y-4 shrink-0">
            <Card>
              <CardContent className="p-2 sm:p-3 flex justify-center">
                <Calendar mode="single" selected={date} onSelect={setDate} className="rounded-md" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-xs text-muted-foreground">Datos de la Cita Seleccionada</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <p className="text-xs text-muted-foreground italic">Haga clic en una cita para ver sus datos</p>
              </CardContent>
            </Card>
            <div className="grid grid-cols-2 lg:grid-cols-1 gap-2">
              <Button variant="outline" size="sm" className="w-full">Atendida</Button>
              <Button variant="outline" size="sm" className="w-full">Actualizar Notas</Button>
              <Button variant="outline" size="sm" className="w-full">Cancelar</Button>
              <Button variant="destructive" size="sm" className="w-full">Eliminar</Button>
              <Button size="sm" className="w-full col-span-2 lg:col-span-1">Buscar Citas Paciente</Button>
            </div>
          </div>
        )}

        {/* Calendar grid */}
        <Card className="flex-1 overflow-hidden">
          <CardContent className="p-0">
            {/* Filters */}
            {isMobile ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full border-b rounded-none"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  Filtros {showFilters ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />}
                </Button>
                {showFilters && (
                  <div className="p-3 border-b space-y-3">
                    <Field label="Médico">
                      <Select defaultValue="todos">
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos</SelectItem>
                          {profesionales.map(p => (
                            <SelectItem key={p.id} value={p.id}>{p.nombre}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field label="Clínica">
                      <Select defaultValue="central">
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="central">Clínica Central</SelectItem>
                          <SelectItem value="norte">Clínica Norte</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                  </div>
                )}
              </>
            ) : (
              <div className="flex items-center gap-3 p-3 border-b">
                <Field label="Médico">
                  <Select defaultValue="todos">
                    <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todos">Todos</SelectItem>
                      {profesionales.map(p => (
                        <SelectItem key={p.id} value={p.id}>{p.nombre}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Clínica">
                  <Select defaultValue="central">
                    <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="central">Clínica Central</SelectItem>
                      <SelectItem value="norte">Clínica Norte</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Días">
                  <Input type="number" defaultValue={3} className="w-16 h-9" />
                </Field>
              </div>
            )}

            <div className="overflow-auto max-h-[500px] md:max-h-[600px]">
              <table className="w-full border-collapse text-xs min-w-[400px]">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <th className="w-14 md:w-16 bg-muted p-1.5 md:p-2 border-b text-xs"></th>
                    {days.map(d => (
                      <th key={d.date} className={`p-1.5 md:p-2 border-b text-left text-xs ${d.today ? "bg-warning/20 font-bold" : "bg-muted"}`}>
                        <span className="font-bold">{d.date}</span> {isMobile ? d.day : d.dayFull}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {hours.map((hour, hi) => (
                    <tr key={hour} className="border-b">
                      <td className="p-1 md:p-2 text-right text-muted-foreground font-mono border-r whitespace-nowrap text-[10px] md:text-xs">{hour}</td>
                      {days.map((_, di) => {
                        const appt = mockAppointments.find(a => a.day === di && a.hour === hi);
                        return (
                          <td key={di} className="p-0.5 md:p-1 border-r h-10 hover:bg-accent/30 cursor-pointer transition-colors">
                            {appt && (
                              <div className="bg-primary/10 border border-primary/20 rounded p-1">
                                <p className="font-medium text-foreground text-[10px] md:text-xs truncate">{appt.patient}</p>
                                <p className="text-muted-foreground text-[9px] md:text-xs truncate">{appt.type} · {appt.doctor}</p>
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function CrearCitaForm({ onClose }: { onClose: () => void }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <Select defaultValue="nombre">
          <SelectTrigger className="w-full sm:w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="nombre">Nombre</SelectItem>
            <SelectItem value="cedula">Cédula</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex gap-2 flex-1">
          <Input placeholder="Buscar paciente..." className="flex-1" />
          <Button size="icon" variant="outline"><Search className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="border rounded-md p-3 bg-accent/20 min-h-[60px]">
        <p className="text-xs text-muted-foreground">Resultados de búsqueda aparecerán aquí</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field label="Médico">
          <Select><SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
            <SelectContent>
              {profesionales.map(p => (
                <SelectItem key={p.id} value={p.id}>{p.nombre}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Tipo de Cita">
          <Select><SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="consulta">Consulta</SelectItem>
              <SelectItem value="control">Control</SelectItem>
              <SelectItem value="primera">Primera vez</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Field label="Fecha"><Input type="date" defaultValue="2026-03-25" /></Field>
        <Field label="Hora Inicio"><Input defaultValue="06:30 PM" /></Field>
        <Field label="Hora Fin"><Input defaultValue="06:35 PM" /></Field>
      </div>

      <Field label="Notas"><Textarea placeholder="Notas de la cita..." /></Field>

      <div className="flex gap-3 justify-end">
        <Button>Crear Cita</Button>
        <Button variant="outline" onClick={onClose}>Cancelar</Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-xs font-medium text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}
