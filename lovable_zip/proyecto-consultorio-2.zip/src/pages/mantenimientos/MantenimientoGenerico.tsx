import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { useIsMobile } from "@/hooks/use-mobile";
import { profesionales, usuarios } from "@/data/mockDoctorData";

type MantenimientoConfig = {
  title: string;
  columns: { key: string; label: string }[];
  data: Record<string, string>[];
  formFields: { key: string; label: string; type?: string; options?: string[] }[];
};

const configs: Record<string, MantenimientoConfig> = {
  clinicas: {
    title: "Clínicas",
    columns: [
      { key: "nombre", label: "Nombre" },
      { key: "direccion", label: "Dirección" },
      { key: "telefono", label: "Teléfono" },
      { key: "estado", label: "Estado" },
    ],
    data: [
      { nombre: "Clínica Central", direccion: "San José Centro", telefono: "2222-1111", estado: "Activa" },
      { nombre: "Clínica Norte", direccion: "Heredia", telefono: "2222-2222", estado: "Activa" },
      { nombre: "Clínica Sur", direccion: "Cartago", telefono: "2222-3333", estado: "Inactiva" },
    ],
    formFields: [
      { key: "nombre", label: "Nombre" },
      { key: "direccion", label: "Dirección" },
      { key: "telefono", label: "Teléfono" },
      { key: "email", label: "Email", type: "email" },
    ],
  },
  profesionales: {
    title: "Profesionales / Médicos",
    columns: [
      { key: "nombre", label: "Nombre" },
      { key: "especialidad", label: "Especialidad" },
      { key: "clinica", label: "Clínica" },
      { key: "estado", label: "Estado" },
    ],
    data: profesionales.map(p => ({
      nombre: p.nombre, especialidad: p.especialidad, clinica: p.clinica, estado: p.estado,
    })),
    formFields: [
      { key: "nombre", label: "Nombre completo" },
      { key: "especialidad", label: "Especialidad" },
      { key: "clinica", label: "Clínica", type: "select", options: ["Clínica Central", "Clínica Norte", "Clínica Sur"] },
      { key: "telefono", label: "Teléfono" },
      { key: "email", label: "Email", type: "email" },
    ],
  },
  usuarios: {
    title: "Usuarios",
    columns: [
      { key: "usuario", label: "Usuario" },
      { key: "nombre", label: "Nombre" },
      { key: "rol", label: "Rol" },
      { key: "profesional", label: "Profesional Vinculado" },
      { key: "estado", label: "Estado" },
    ],
    data: usuarios.map(u => ({
      usuario: u.usuario, nombre: u.nombre, rol: u.rol, estado: u.estado,
      profesional: u.profesionalId ? profesionales.find(p => p.id === u.profesionalId)?.nombre ?? "—" : "—",
    })),
    formFields: [
      { key: "usuario", label: "Usuario" },
      { key: "nombre", label: "Nombre completo" },
      { key: "rol", label: "Rol", type: "select", options: ["Administrador", "Médico", "Recepción", "Enfermería"] },
      { key: "password", label: "Contraseña", type: "password" },
    ],
  },
  "tipos-cita": {
    title: "Tipos de Cita",
    columns: [
      { key: "nombre", label: "Nombre" },
      { key: "duracion", label: "Duración (min)" },
      { key: "estado", label: "Estado" },
    ],
    data: [
      { nombre: "Consulta General", duracion: "30", estado: "Activo" },
      { nombre: "Control", duracion: "15", estado: "Activo" },
      { nombre: "Primera Vez", duracion: "45", estado: "Activo" },
      { nombre: "Seguimiento", duracion: "20", estado: "Activo" },
    ],
    formFields: [
      { key: "nombre", label: "Nombre" },
      { key: "duracion", label: "Duración (minutos)", type: "number" },
    ],
  },
  tratamientos: {
    title: "Tratamientos",
    columns: [
      { key: "codigo", label: "Código" },
      { key: "nombre", label: "Nombre" },
      { key: "categoria", label: "Categoría" },
      { key: "precio", label: "Precio" },
    ],
    data: [
      { codigo: "TRT-001", nombre: "Limpieza Dental", categoria: "Preventivo", precio: "₡25,000" },
      { codigo: "TRT-002", nombre: "Extracción Simple", categoria: "Cirugía", precio: "₡35,000" },
      { codigo: "TRT-003", nombre: "Resina", categoria: "Restauración", precio: "₡40,000" },
    ],
    formFields: [
      { key: "codigo", label: "Código" },
      { key: "nombre", label: "Nombre" },
      { key: "categoria", label: "Categoría", type: "select", options: ["Preventivo", "Cirugía", "Restauración", "Ortodoncia"] },
      { key: "precio", label: "Precio" },
    ],
  },
};

export default function MantenimientoGenerico({ tipo }: { tipo: string }) {
  const config = configs[tipo];
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const isMobile = useIsMobile();

  if (!config) return <div className="p-6">Mantenimiento no encontrado</div>;

  const filtered = config.data.filter(row =>
    Object.values(row).some(v => v.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h1 className="text-xl md:text-2xl font-bold text-foreground">{config.title}</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size={isMobile ? "sm" : "default"}><Plus className="h-4 w-4 mr-1" /> Nuevo</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Nuevo registro - {config.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {config.formFields.map(f => (
                <div key={f.key} className="space-y-1">
                  <Label className="text-sm">{f.label}</Label>
                  {f.type === "select" ? (
                    <Select>
                      <SelectTrigger><SelectValue placeholder="Seleccione..." /></SelectTrigger>
                      <SelectContent>
                        {f.options?.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input type={f.type || "text"} />
                  )}
                </div>
              ))}
              <div className="flex items-center gap-2">
                <Switch id="active" defaultChecked />
                <Label htmlFor="active">Activo</Label>
              </div>
              <div className="flex gap-3 justify-end">
                <Button>Guardar</Button>
                <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="pt-4">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          {isMobile ? (
            <div className="divide-y -mx-4">
              {filtered.map((row, i) => (
                <div key={i} className="px-4 py-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm text-foreground">{row[config.columns[0].key]}</span>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7"><Pencil className="h-3 w-3" /></Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive"><Trash2 className="h-3 w-3" /></Button>
                    </div>
                  </div>
                  {config.columns.slice(1).map(c => (
                    <div key={c.key} className="flex justify-between text-xs">
                      <span className="text-muted-foreground">{c.label}</span>
                      <span>{row[c.key]}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  {config.columns.map(c => <TableHead key={c.key}>{c.label}</TableHead>)}
                  <TableHead className="w-24">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((row, i) => (
                  <TableRow key={i}>
                    {config.columns.map(c => <TableCell key={c.key}>{row[c.key]}</TableCell>)}
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-7 w-7"><Pencil className="h-3 w-3" /></Button>
                        <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive"><Trash2 className="h-3 w-3" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
