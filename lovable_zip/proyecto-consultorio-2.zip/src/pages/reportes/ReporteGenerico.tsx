import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Filter, Printer, ChevronDown, ChevronUp } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

type ReporteConfig = {
  title: string;
  filters: { key: string; label: string; type: string; options?: string[] }[];
  columns: { key: string; label: string }[];
  data: Record<string, string>[];
};

const configs: Record<string, ReporteConfig> = {
  citas: {
    title: "Reporte de Citas",
    filters: [
      { key: "desde", label: "Desde", type: "date" },
      { key: "hasta", label: "Hasta", type: "date" },
      { key: "medico", label: "Médico", type: "select", options: ["Todos", "Dr. García", "Dr. Sánchez", "Dra. Vargas"] },
      { key: "clinica", label: "Clínica", type: "select", options: ["Todas", "Clínica Central", "Clínica Norte", "Clínica Sur"] },
      { key: "estado", label: "Estado", type: "select", options: ["Todos", "Atendida", "Pendiente", "Cancelada"] },
    ],
    columns: [
      { key: "fecha", label: "Fecha" }, { key: "hora", label: "Hora" },
      { key: "paciente", label: "Paciente" }, { key: "medico", label: "Médico" },
      { key: "tipo", label: "Tipo" }, { key: "estado", label: "Estado" },
    ],
    data: [
      { fecha: "25/03/2026", hora: "10:00 AM", paciente: "María López", medico: "Dr. García", tipo: "Consulta", estado: "Atendida" },
      { fecha: "25/03/2026", hora: "10:30 AM", paciente: "Juan Pérez", medico: "Dr. García", tipo: "Control", estado: "Pendiente" },
      { fecha: "25/03/2026", hora: "11:00 AM", paciente: "Ana Rodríguez", medico: "Dr. Sánchez", tipo: "Primera vez", estado: "Atendida" },
      { fecha: "24/03/2026", hora: "09:00 AM", paciente: "Carlos Jiménez", medico: "Dra. Vargas", tipo: "Seguimiento", estado: "Cancelada" },
      { fecha: "24/03/2026", hora: "14:00 PM", paciente: "Laura Mora", medico: "Dr. García", tipo: "Consulta", estado: "Atendida" },
    ],
  },
  pacientes: {
    title: "Reporte de Pacientes",
    filters: [
      { key: "clinica", label: "Clínica", type: "select", options: ["Todas", "Clínica Central", "Clínica Norte", "Clínica Sur"] },
      { key: "medico", label: "Médico", type: "select", options: ["Todos", "Dr. García", "Dr. Sánchez", "Dra. Vargas"] },
      { key: "sexo", label: "Sexo", type: "select", options: ["Todos", "Masculino", "Femenino"] },
    ],
    columns: [
      { key: "nombre", label: "Nombre" }, { key: "cedula", label: "Cédula" },
      { key: "telefono", label: "Teléfono" }, { key: "clinica", label: "Clínica" },
      { key: "medico", label: "Médico" }, { key: "ultimaVisita", label: "Última Visita" },
    ],
    data: [
      { nombre: "María López", cedula: "1-0234-0567", telefono: "8812-3456", clinica: "Clínica Central", medico: "Dr. García", ultimaVisita: "25/03/2026" },
      { nombre: "Juan Pérez", cedula: "3-0456-0789", telefono: "7734-5678", clinica: "Clínica Norte", medico: "Dr. Sánchez", ultimaVisita: "24/03/2026" },
      { nombre: "Ana Rodríguez", cedula: "2-0678-0123", telefono: "6656-7890", clinica: "Clínica Central", medico: "Dr. García", ultimaVisita: "23/03/2026" },
    ],
  },
  clinicas: {
    title: "Reporte de Clínicas",
    filters: [
      { key: "estado", label: "Estado", type: "select", options: ["Todas", "Activa", "Inactiva"] },
    ],
    columns: [
      { key: "nombre", label: "Nombre" }, { key: "direccion", label: "Dirección" },
      { key: "telefono", label: "Teléfono" }, { key: "medicos", label: "Médicos" },
      { key: "pacientes", label: "Pacientes" }, { key: "estado", label: "Estado" },
    ],
    data: [
      { nombre: "Clínica Central", direccion: "San José Centro", telefono: "2222-1111", medicos: "2", pacientes: "1,203", estado: "Activa" },
      { nombre: "Clínica Norte", direccion: "Heredia", telefono: "2222-2222", medicos: "1", pacientes: "412", estado: "Activa" },
      { nombre: "Clínica Sur", direccion: "Cartago", telefono: "2222-3333", medicos: "0", pacientes: "232", estado: "Inactiva" },
    ],
  },
  tratamientos: {
    title: "Reporte de Tratamientos",
    filters: [
      { key: "desde", label: "Desde", type: "date" },
      { key: "hasta", label: "Hasta", type: "date" },
      { key: "categoria", label: "Categoría", type: "select", options: ["Todas", "Preventivo", "Cirugía", "Restauración"] },
    ],
    columns: [
      { key: "codigo", label: "Código" }, { key: "tratamiento", label: "Tratamiento" },
      { key: "categoria", label: "Categoría" }, { key: "cantidad", label: "Cantidad" },
      { key: "ingresos", label: "Ingresos" },
    ],
    data: [
      { codigo: "TRT-001", tratamiento: "Limpieza Dental", categoria: "Preventivo", cantidad: "45", ingresos: "₡1,125,000" },
      { codigo: "TRT-002", tratamiento: "Extracción Simple", categoria: "Cirugía", cantidad: "12", ingresos: "₡420,000" },
      { codigo: "TRT-003", tratamiento: "Resina", categoria: "Restauración", cantidad: "28", ingresos: "₡1,120,000" },
    ],
  },
  usuarios: {
    title: "Reporte de Usuarios",
    filters: [
      { key: "rol", label: "Rol", type: "select", options: ["Todos", "Administrador", "Médico", "Recepción", "Enfermería"] },
      { key: "estado", label: "Estado", type: "select", options: ["Todos", "Activo", "Inactivo"] },
    ],
    columns: [
      { key: "usuario", label: "Usuario" }, { key: "nombre", label: "Nombre" },
      { key: "rol", label: "Rol" }, { key: "ultimoAcceso", label: "Último Acceso" },
      { key: "estado", label: "Estado" },
    ],
    data: [
      { usuario: "admin", nombre: "Administrador", rol: "Administrador", ultimoAcceso: "25/03/2026 14:30", estado: "Activo" },
      { usuario: "dgarcia", nombre: "Dr. García", rol: "Médico", ultimoAcceso: "25/03/2026 13:45", estado: "Activo" },
      { usuario: "recepcion1", nombre: "Laura Mora", rol: "Recepción", ultimoAcceso: "25/03/2026 08:00", estado: "Activo" },
    ],
  },
};

export default function ReporteGenerico({ tipo }: { tipo: string }) {
  const config = configs[tipo];
  const isMobile = useIsMobile();
  const [showFilters, setShowFilters] = useState(!isMobile);

  if (!config) return <div className="p-6">Reporte no encontrado</div>;

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <h1 className="text-xl md:text-2xl font-bold text-foreground">{config.title}</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Printer className="h-4 w-4 mr-1" /> <span className="hidden sm:inline">Imprimir</span></Button>
          <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-1" /> <span className="hidden sm:inline">Exportar</span></Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-4">
          {isMobile && (
            <Button
              variant="ghost"
              size="sm"
              className="w-full mb-3"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-1" /> Filtros {showFilters ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />}
            </Button>
          )}
          {showFilters && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:flex md:flex-wrap items-end gap-3 mb-4">
              {config.filters.map(f => (
                <div key={f.key} className="space-y-1">
                  <label className="text-xs font-medium text-muted-foreground">{f.label}</label>
                  {f.type === "select" ? (
                    <Select defaultValue={f.options?.[0]}>
                      <SelectTrigger className="w-full md:w-40"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {f.options?.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input type={f.type} className="w-full md:w-40" />
                  )}
                </div>
              ))}
              <Button size="sm" className="w-full sm:w-auto"><Filter className="h-4 w-4 mr-1" /> Filtrar</Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isMobile ? (
            <div className="divide-y">
              {config.data.map((row, i) => (
                <div key={i} className="p-3 space-y-1">
                  {config.columns.map(c => (
                    <div key={c.key} className="flex justify-between text-sm">
                      <span className="text-muted-foreground text-xs">{c.label}</span>
                      <span className="text-foreground text-xs font-medium">{row[c.key]}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          ) : (
            <div className="overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {config.columns.map(c => <TableHead key={c.key}>{c.label}</TableHead>)}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {config.data.map((row, i) => (
                    <TableRow key={i}>
                      {config.columns.map(c => <TableCell key={c.key}>{row[c.key]}</TableCell>)}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          <div className="p-3 border-t text-xs text-muted-foreground">
            Mostrando {config.data.length} registros
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
