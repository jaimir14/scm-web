import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings, Save } from "lucide-react";

export default function Configuracion() {
  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="h-5 w-5 md:h-6 md:w-6 text-primary" />
        <h1 className="text-xl md:text-2xl font-bold text-foreground">Configuración del Sistema</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base">General</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label>Nombre del Sistema</Label>
              <Input defaultValue="SCM - Sistema Clínico Médico" />
            </div>
            <div className="space-y-1">
              <Label>Zona Horaria</Label>
              <Select defaultValue="america_costa_rica">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="america_costa_rica">América/Costa Rica (UTC-6)</SelectItem>
                  <SelectItem value="america_panama">América/Panamá (UTC-5)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Formato de Fecha</Label>
              <Select defaultValue="dd/mm/yyyy">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="dd/mm/yyyy">DD/MM/YYYY</SelectItem>
                  <SelectItem value="mm/dd/yyyy">MM/DD/YYYY</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Citas</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1">
              <Label>Duración por defecto (min)</Label>
              <Input type="number" defaultValue="30" />
            </div>
            <div className="space-y-1">
              <Label>Hora inicio jornada</Label>
              <Input defaultValue="08:00" type="time" />
            </div>
            <div className="space-y-1">
              <Label>Hora fin jornada</Label>
              <Input defaultValue="18:00" type="time" />
            </div>
            <div className="flex items-center gap-2">
              <Switch defaultChecked />
              <Label>Restricción de horario</Label>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Seguridad</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <Switch defaultChecked />
              <Label>Registrar en bitácora</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch defaultChecked />
              <Label className="leading-tight">Requerir cambio de contraseña cada 90 días</Label>
            </div>
            <div className="space-y-1">
              <Label>Tiempo de inactividad (min)</Label>
              <Input type="number" defaultValue="30" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Notificaciones</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <Switch />
              <Label>Enviar recordatorio de citas por email</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch />
              <Label>Notificar al médico de nuevas citas</Label>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-center">
        <Button size="lg"><Save className="h-4 w-4 mr-2" /> Guardar Configuración</Button>
      </div>
    </div>
  );
}
