import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useIsMobile } from "@/hooks/use-mobile";

const mockPatients = [
  { id: "1", nombre: "María López Jiménez", cedula: "1-0234-0567", telefono: "8812-3456", clinica: "Clínica Central" },
  { id: "2", nombre: "Juan Pérez Mora", cedula: "3-0456-0789", telefono: "7734-5678", clinica: "Clínica Norte" },
  { id: "3", nombre: "Ana Rodríguez Solano", cedula: "2-0678-0123", telefono: "6656-7890", clinica: "Clínica Central" },
  { id: "4", nombre: "Carlos Jiménez Arias", cedula: "1-0890-0345", telefono: "8898-9012", clinica: "Clínica Sur" },
  { id: "5", nombre: "Laura Mora Herrera", cedula: "4-0123-0678", telefono: "7712-3456", clinica: "Clínica Central" },
];

export default function BuscarExpediente() {
  const navigate = useNavigate();
  const [searchType, setSearchType] = useState("nombre");
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(mockPatients);
  const isMobile = useIsMobile();

  const handleSearch = () => {
    if (!query) { setResults(mockPatients); return; }
    setResults(mockPatients.filter(p =>
      searchType === "nombre"
        ? p.nombre.toLowerCase().includes(query.toLowerCase())
        : p.cedula.includes(query)
    ));
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      <h1 className="text-xl md:text-2xl font-bold text-foreground">Búsqueda de Expediente</h1>

      <Card>
        <CardContent className="pt-5">
          <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-end gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Buscar por</label>
              <Select value={searchType} onValueChange={setSearchType}>
                <SelectTrigger className="w-full sm:w-44"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="nombre">Nombre</SelectItem>
                  <SelectItem value="cedula">Cédula</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 min-w-0 space-y-1">
              <label className="text-xs font-medium text-muted-foreground">Paciente</label>
              <Input
                placeholder="Digite un texto y presione Enter para buscar"
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} className="w-full sm:w-auto"><Search className="h-4 w-4 mr-1" /> Buscar</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isMobile ? (
            <div className="divide-y">
              {results.map(p => (
                <div
                  key={p.id}
                  className="p-3 hover:bg-accent/50 cursor-pointer active:bg-accent/70"
                  onClick={() => navigate(`/expediente/${p.id}`)}
                >
                  <p className="font-medium text-sm text-foreground">{p.nombre}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{p.cedula} · {p.telefono}</p>
                  <p className="text-xs text-muted-foreground">{p.clinica}</p>
                </div>
              ))}
              {results.length === 0 && (
                <div className="p-6 text-center text-muted-foreground text-sm">No se encontraron resultados</div>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Cédula</TableHead>
                  <TableHead>Teléfono</TableHead>
                  <TableHead>Clínica</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map(p => (
                  <TableRow
                    key={p.id}
                    className="cursor-pointer hover:bg-accent/50"
                    onClick={() => navigate(`/expediente/${p.id}`)}
                  >
                    <TableCell className="font-medium">{p.nombre}</TableCell>
                    <TableCell>{p.cedula}</TableCell>
                    <TableCell>{p.telefono}</TableCell>
                    <TableCell>{p.clinica}</TableCell>
                  </TableRow>
                ))}
                {results.length === 0 && (
                  <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No se encontraron resultados</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
